package com.example.project.sms.controller;

import com.example.project.sms.dto.StudentRequestDto;
import com.example.project.sms.dto.StudentResponseDto;
import com.example.project.sms.entity.Student;
import com.example.project.sms.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentController {
    @Autowired
    public final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/{id}")
    public StudentResponseDto getById(@PathVariable Long id) {
        return studentService.getId(id);
    }
    @GetMapping("/getAll")
    public List<StudentResponseDto> getAll(){
        return studentService.getAll();
    }
    @PostMapping
    public StudentResponseDto createStud(@RequestBody StudentRequestDto dto){
        return studentService.saveStud(dto);
    }
    @PutMapping("/update")
    public StudentResponseDto updateStudent(@PathVariable Long id,@RequestBody StudentRequestDto dto){
        return studentService.updateStud(id,dto);
    }
    @PatchMapping("/partUpdate/{id}")
    public StudentResponseDto partialUpdate(@RequestBody StudentRequestDto dto,@PathVariable Long id){
        return studentService.partUpdate(dto,id);
    }
    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable Long id){
        studentService.deleteById(id);
        return "Student Deleted";
    }
}
