package com.example.project.sms.dto;

import lombok.Data;

@Data
public class StudentRequestDto {
    private String firstName;
    private String lastName;
    private String Number;
    private String email;
}
